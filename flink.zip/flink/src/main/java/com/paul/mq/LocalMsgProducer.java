package com.paul.mq;

import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.ONSFactory;
import com.aliyun.openservices.ons.api.OnExceptionContext;
import com.aliyun.openservices.ons.api.Producer;
import com.aliyun.openservices.ons.api.PropertyKeyConst;
import com.aliyun.openservices.ons.api.SendCallback;
import com.aliyun.openservices.ons.api.SendResult;
import com.aliyun.openservices.ons.api.exception.ONSClientException;
import com.paul.kfk.LocalKfkMsgProducer;

import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocalMsgProducer {
    private static final String END_POINT_PRIVATE = "http://MQ_INST_1584883537861188_BYlLsqNV.cn-shanghai.mq-vpc.aliyuncs.com:8080";
    private static final String END_POINT_PUBLIC = "http://MQ_INST_1584883537861188_BYlLsqNV.cn-shanghai.mq.aliyuncs.com:80";
    private static final String USER_NAME = "LTAI5tPxzpf4YtQ14vGyFXUo";
    private static final String PASS_WORD = "EDI2qjiNlVMz6ytkYAMULyRzcWdFnX";
    private static final String INPUT_TOPIC = "CB_ET_POC_INPUT";
    private static final String INPUT_CONSUMER_GROUP = "GID_CB_ET_INPUT_CONSUMER_GROUP";
    private static final String OUTPUT_TOPIC = "CB_ET_POC_OUTPUT";
    private static final String OUTPUT_CONSUMER_GROUP = "GID_CB_ET_OUTPUT_CONSUMER_GROUP";
    private static final String TAG = "POC";
    private static final Properties PROPERTIES = new Properties();
    private static final int MESSAGE_COUNT = 1000;
    private static final Producer PRODUCER;
    private static final ExecutorService EXECUTOR_SERVICE = Executors.newFixedThreadPool(4);

    static {
        PROPERTIES.put(PropertyKeyConst.AccessKey, USER_NAME);
        PROPERTIES.put(PropertyKeyConst.SecretKey, PASS_WORD);
        PROPERTIES.put(PropertyKeyConst.SendMsgTimeoutMillis, "3000");
        PROPERTIES.put(PropertyKeyConst.NAMESRV_ADDR, END_POINT_PUBLIC);
        PRODUCER = ONSFactory.createProducer(PROPERTIES);
        PRODUCER.start();
    }


    public static void main(String[] args) throws Exception {
        for (int i = 0; i < 1000; i++) {
            String prefix = UUID.randomUUID().toString().replace("-", "");
            String[] msgArray = new String[MESSAGE_COUNT];
            for (int idx = 0; idx < msgArray.length; idx++) {
                msgArray[idx] = LocalKfkMsgProducer.generateEventMsg(prefix, idx);
            }
            EXECUTOR_SERVICE.submit(() -> doSend(msgArray));
        }
    }

    private static void doSend(String... msgArray) {
        long startTime = System.currentTimeMillis();
       // CountDownLatch countDownLatch = new CountDownLatch(msgArray.length);
        for (String msg : msgArray) {
            Message message = new Message(INPUT_TOPIC, TAG, msg.getBytes());
            PRODUCER.sendAsync(message, new SendCallback() {
                @Override
                public void onSuccess(SendResult sendResult) {
                   // countDownLatch.countDown();
                }

                @Override
                public void onException(OnExceptionContext onExceptionContext) {
                    //countDownLatch.countDown();
                    ONSClientException e = onExceptionContext.getException();
                    System.err.println(Thread.currentThread().getName() + " ==> Failed: " + e.getMessage());
                    e.printStackTrace();
                }
            });
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        /*try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
        long endTime = System.currentTimeMillis();
        System.out.println(Thread.currentThread().getName() + " ==> Send " + msgArray.length + " records, cost: " + (endTime - startTime) + " ms.");
    }
}
