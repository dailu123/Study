package com.paul.mq;

import com.aliyun.openservices.ons.api.Action;
import com.aliyun.openservices.ons.api.Consumer;
import com.aliyun.openservices.ons.api.ONSFactory;
import com.aliyun.openservices.ons.api.PropertyKeyConst;

import java.util.Properties;


public class LocalMsgConsumer {
    private static final String END_POINT_PRIVATE = "http://MQ_INST_1584883537861188_BYlLsqNV.cn-shanghai.mq-vpc.aliyuncs.com:8080";
    private static final String END_POINT_PUBLIC = "http://MQ_INST_1584883537861188_BYlLsqNV.cn-shanghai.mq.aliyuncs.com:80";
    private static final String USER_NAME = "LTAI5tPxzpf4YtQ14vGyFXUo";
    private static final String PASS_WORD = "EDI2qjiNlVMz6ytkYAMULyRzcWdFnX";
    private static final String INPUT_TOPIC = "CB_ET_POC_INPUT";
    private static final String INPUT_CONSUMER_GROUP = "GID_CB_ET_INPUT_CONSUMER_GROUP";
    private static final String OUTPUT_TOPIC = "CB_ET_POC_OUTPUT";
    private static final String OUTPUT_CONSUMER_GROUP = "GID_CB_ET_OUTPUT_CONSUMER_GROUP";
    private static final String TAG = "POC";
    private static final Properties PROPERTIES = new Properties();

    static {
        PROPERTIES.put(PropertyKeyConst.AccessKey, USER_NAME);
        PROPERTIES.put(PropertyKeyConst.SecretKey, PASS_WORD);
        PROPERTIES.put(PropertyKeyConst.NAMESRV_ADDR, END_POINT_PUBLIC);
        PROPERTIES.setProperty(PropertyKeyConst.GROUP_ID, OUTPUT_CONSUMER_GROUP);
    }

    public static void main(String[] args) {
        Consumer consumer = ONSFactory.createConsumer(PROPERTIES);
        consumer.subscribe(OUTPUT_TOPIC, TAG, (message, context) -> {
            System.out.println(String.format("Get msg[%s]: %s", message.getMsgID(), new String(message.getBody())));
            return Action.CommitMessage;
        });
        consumer.start();
        System.out.println("Consumer started ...");
    }
}
