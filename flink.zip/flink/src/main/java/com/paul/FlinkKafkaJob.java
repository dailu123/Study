package com.paul;

import com.paul.pipline.processor.CustomProcessor;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.connector.kafka.source.reader.deserializer.KafkaRecordDeserializationSchema;
import org.apache.flink.kafka.shaded.org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer;
import org.apache.flink.streaming.connectors.kafka.internals.KafkaSerializationSchemaWrapper;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;

import java.util.Properties;

public class FlinkKafkaJob {
    private static final String BOOTSTRAP_SERVER = "106.15.57.104:9092";
    private static final String INPUT_TOPIC = "INPUT_TOPIC";
    private static final String OUTPUT_TOPIC = "OUTPUT_TOPIC";
    private static final String CONSUMER_GROUP_01 = "CONSUMER_GROUP_01";

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> dataStreamSource = env.fromSource(createKafkaSource(), WatermarkStrategy.noWatermarks(), "Kafka Source").setParallelism(1);
        SingleOutputStreamOperator<String> streamOperator = dataStreamSource.process(new CustomProcessor()).name("Custom Processor");
        streamOperator.addSink(createKafkaSink()).name("Kafka Sink").setParallelism(1);
        env.execute();
    }

    private static KafkaSource<String> createKafkaSource() {
        return KafkaSource.<String>builder()
                .setBootstrapServers(BOOTSTRAP_SERVER)
                .setTopics(INPUT_TOPIC)
                .setStartingOffsets(OffsetsInitializer.committedOffsets())
                .setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest")
                .setGroupId(CONSUMER_GROUP_01)
                .setDeserializer(KafkaRecordDeserializationSchema.valueOnly(StringDeserializer.class))
                .build();
    }

    private static FlinkKafkaProducer<String> createKafkaSink() {
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVER);
        return new FlinkKafkaProducer<>(
                OUTPUT_TOPIC,
                new KafkaSerializationSchemaWrapper<>(OUTPUT_TOPIC, null, true, new SimpleStringSchema()),
                properties,
                FlinkKafkaProducer.Semantic.AT_LEAST_ONCE);
    }
}
