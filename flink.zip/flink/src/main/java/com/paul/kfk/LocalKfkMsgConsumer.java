package com.paul.kfk;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

public class LocalKfkMsgConsumer {
    private static final String BOOTSTRAP_SERVER = "106.14.217.171:9092";//"106.15.57.104:9092";
    //private static final String BOOTSTRAP_SERVER = "127.0.0.1:9092";
    private static final String INPUT_TOPIC = "INPUT_TOPIC";
    private static final String OUTPUT_TOPIC = "OUTPUT_TOPIC";
    private static final String PAUL_PRIVATE = "PAUL_PRIVATE";
    private static final String CONSUMER_GROUP_01 = "CONSUMER_GROUP_01";
    private static final String CONSUMER_GROUP_02 = "CONSUMER_GROUP_02";
    private static final String CONSUMER_GROUP_03 = "CONSUMER_GROUP_03";
    private static final Properties PROPERTIES = new Properties();

    static {
        PROPERTIES.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVER);
        PROPERTIES.setProperty(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
        PROPERTIES.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
        PROPERTIES.setProperty(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "1000");
        String selName = StringDeserializer.class.getName();
        PROPERTIES.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, selName);
        PROPERTIES.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, selName);
        PROPERTIES.put(ConsumerConfig.GROUP_ID_CONFIG, CONSUMER_GROUP_03);
        PROPERTIES.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
    }

    public static void main(String[] args) {
        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(PROPERTIES);
        consumer.subscribe(Collections.singletonList(PAUL_PRIVATE));
        long startTime = System.currentTimeMillis();
        while (true) {
            System.out.println("--------- Polling ----------");
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(1000));
            if (records == null || records.isEmpty()) {
                continue;
            }
            records.forEach(record -> {
                int partition = record.partition();
                long offset = record.offset();
                long endTime = System.currentTimeMillis();
                System.out.println("Partition: " + partition + ", Offset: " + offset + ", Cost: " + (endTime - startTime) + " ms");
            });
        }
    }
}
