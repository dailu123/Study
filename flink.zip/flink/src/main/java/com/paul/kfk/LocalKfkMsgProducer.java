package com.paul.kfk;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paul.pojo.EventDetail;
import com.paul.pojo.EventHeader;
import com.paul.pojo.TransactionEvent;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocalKfkMsgProducer {
    private static final String BOOTSTRAP_SERVER = "106.14.217.171:9092";//"106.15.57.104:9092";
    //private static final String BOOTSTRAP_SERVER = "127.0.0.1:9092";
    private static final String INPUT_TOPIC = "PAUL_PRIVATE";
    private static final String OUTPUT_TOPIC = "OUTPUT_TOPIC";
    private static final Properties PROPERTIES = new Properties();
    private static final int MESSAGE_COUNT = 1000;
    private static final ExecutorService EXECUTOR_SERVICE = Executors.newFixedThreadPool(4);

    static {
        PROPERTIES.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVER);
        String selName = StringSerializer.class.getName();
        PROPERTIES.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, selName);
        PROPERTIES.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, selName);
    }

    public static void main(String[] args) throws Exception {
        for (int i = 0; i < 100; i++) {
            String prefix = UUID.randomUUID().toString().replace("-", "");
            String[] msgArray = new String[MESSAGE_COUNT];
            for (int idx = 0; idx < msgArray.length; idx++) {
                msgArray[idx] = generateEventMsg(prefix, idx);
            }
            EXECUTOR_SERVICE.submit(() -> sendMsg(msgArray));
        }
    }

    public static String generateEventMsg(String idPrefix, int idx) throws JsonProcessingException {
        EventHeader header = new EventHeader();
        header.setCountry(idx % 2 == 0 ? "AU" : "MY");
        header.setEventIdentifier(idPrefix + "_" + idx);
        header.setSourceSystem("Local");
        header.setSystemTimestamp(Long.toString(System.currentTimeMillis()));
        EventDetail detail = new EventDetail();
        detail.setTransactionAccount("AC_" + idx);
        detail.setTransactionType(idx % 2 == 0 ? "CR" : "DR");
        TransactionEvent event = new TransactionEvent(header, detail);
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(event);
    }

    private static void sendMsg(String... msgArray) {
        long startTime = System.currentTimeMillis();
        KafkaProducer<String, String> producer = new KafkaProducer<>(PROPERTIES);
        for (String msg : msgArray) {
            producer.send(new ProducerRecord<>(INPUT_TOPIC, msg), (recordMetadata, e) -> {
                if (e != null) {
                    System.out.println("Failed: " + msg);
                    e.printStackTrace();
                } else {
                    System.out.println("Success, Partition: " + recordMetadata.partition() + ", Offset: " + recordMetadata.offset());
                }
            });
        }
        producer.flush();
        producer.close();
        long endTime = System.currentTimeMillis();
        System.out.println(Thread.currentThread().getName() + " ==> Send " + msgArray.length + " records, cost: " + (endTime - startTime) + " ms.");
    }
}
