package com.paul.pojo;

public class TransactionEvent {
    private EventHeader eventHeader;
    private EventDetail eventDetails;

    public TransactionEvent() {
    }

    public TransactionEvent(EventHeader eventHeader, EventDetail eventDetails) {
        this.eventHeader = eventHeader;
        this.eventDetails = eventDetails;
    }

    public EventHeader getEventHeader() {
        return eventHeader;
    }

    public void setEventHeader(EventHeader eventHeader) {
        this.eventHeader = eventHeader;
    }

    public EventDetail getEventDetails() {
        return eventDetails;
    }

    public void setEventDetails(EventDetail eventDetails) {
        this.eventDetails = eventDetails;
    }
}

