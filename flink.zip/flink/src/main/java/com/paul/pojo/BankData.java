package com.paul.pojo;

public class BankData {
    private String job;
    private String eduction;

    public BankData(String job, String eduction) {
        this.job = job;
        this.eduction = eduction;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getEduction() {
        return eduction;
    }

    public void setEduction(String eduction) {
        this.eduction = eduction;
    }

    @Override
    public String toString() {
        return "('" + job + "','" + eduction + "')";
    }
}
