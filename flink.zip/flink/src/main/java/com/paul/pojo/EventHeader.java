package com.paul.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EventHeader {
    private String country;
    private String sourceSystem;
    private String eventIdentifier;
    private String systemTimestamp;

    public EventHeader() {
    }

    public EventHeader(String country, String sourceSystem, String eventIdentifier, String systemTimestamp) {
        this.country = country;
        this.sourceSystem = sourceSystem;
        this.eventIdentifier = eventIdentifier;
        this.systemTimestamp = systemTimestamp;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getEventIdentifier() {
        return eventIdentifier;
    }

    public void setEventIdentifier(String eventIdentifier) {
        this.eventIdentifier = eventIdentifier;
    }

    public String getSystemTimestamp() {
        return systemTimestamp;
    }

    public void setSystemTimestamp(String systemTimestamp) {
        this.systemTimestamp = systemTimestamp;
    }
}
