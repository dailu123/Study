package com.paul.pojo;

public class DownStreamMessage {
    private String country;
    private String sourceSystem;
    private String eventIdentifier;
    private String systemTimestamp;
    private String transactionAccount;
    private String transactionType;
    private String processTime;


    public DownStreamMessage() {
    }

    public DownStreamMessage(String country, String sourceSystem, String eventIdentifier, String systemTimestamp, String transactionAccount, String transactionType, String processTime) {
        this.country = country;
        this.sourceSystem = sourceSystem;
        this.eventIdentifier = eventIdentifier;
        this.systemTimestamp = systemTimestamp;
        this.transactionAccount = transactionAccount;
        this.transactionType = transactionType;
        this.processTime = processTime;
    }


    public String getProcessTime() {
        return processTime;
    }

    public void setProcessTime(String processTime) {
        this.processTime = processTime;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getEventIdentifier() {
        return eventIdentifier;
    }

    public void setEventIdentifier(String eventIdentifier) {
        this.eventIdentifier = eventIdentifier;
    }

    public String getSystemTimestamp() {
        return systemTimestamp;
    }

    public void setSystemTimestamp(String systemTimestamp) {
        this.systemTimestamp = systemTimestamp;
    }

    public String getTransactionAccount() {
        return transactionAccount;
    }

    public void setTransactionAccount(String transactionAccount) {
        this.transactionAccount = transactionAccount;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public void copyPropertyFromEvent(TransactionEvent event) {
        EventHeader header = event.getEventHeader();
        EventDetail detail = event.getEventDetails();
        this.country = header.getCountry();
        this.sourceSystem = header.getSourceSystem();
        this.eventIdentifier = header.getEventIdentifier();
        this.systemTimestamp = header.getSystemTimestamp();
        this.transactionType = detail.getTransactionType();
        this.transactionAccount = detail.getTransactionAccount();
    }
}
