package com.paul.pipline.filter.matcher;

import java.util.List;

public interface ValueMatcher {
    boolean match(String actValue, List<String> cfgValueList);
}
