package com.paul.pipline.filter.matcher;

import java.util.List;

public class IncludeMatcher implements ValueMatcher{
    @Override
    public boolean match(String actValue, List<String> cfgValueList) {
        return cfgValueList.contains(actValue);
    }
}
