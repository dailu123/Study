package com.paul.pipline.filter;

import java.util.List;

public class FilterModel {
    private String filterKey;
    private String filterStrategy;
    private List<String> filterValues;

    public FilterModel() {
    }

    public FilterModel(String filterKey, String filterStrategy, List<String> filterValues) {
        this.filterKey = filterKey;
        this.filterStrategy = filterStrategy;
        this.filterValues = filterValues;
    }

    public String getFilterKey() {
        return filterKey;
    }

    public void setFilterKey(String filterKey) {
        this.filterKey = filterKey;
    }

    public String getFilterStrategy() {
        return filterStrategy;
    }

    public void setFilterStrategy(String filterStrategy) {
        this.filterStrategy = filterStrategy;
    }

    public List<String> getFilterValues() {
        return filterValues;
    }

    public void setFilterValues(List<String> filterValues) {
        this.filterValues = filterValues;
    }
}
