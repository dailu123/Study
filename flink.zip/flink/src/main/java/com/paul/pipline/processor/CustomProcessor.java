package com.paul.pipline.processor;

import com.aliyun.odps.data.Record;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paul.pipline.convert.MessageConvert;
import com.paul.pipline.filter.FilterConfig;
import com.paul.pipline.filter.FilterModel;
import com.paul.pipline.filter.matcher.MatcherFactory;
import com.paul.pipline.filter.matcher.ValueMatcher;
import com.paul.pojo.DownStreamMessage;
import com.paul.pojo.TransactionEvent;
import com.paul.sql.MaxComputeClient;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CustomProcessor extends ProcessFunction<String, String> {
    private static final Logger LOGGER = LoggerFactory.getLogger(CustomProcessor.class);
    private static final String FILTER_CONFIG_PATH = "/flink/usrlib/filter_config.json";
    private static final FilterConfig FILTER_CONFIG;

    static {
        FILTER_CONFIG = loadFilterConfig();
        loadId();
    }

    private static FilterConfig loadFilterConfig() {
        FilterConfig config;
        ObjectMapper mapper = new ObjectMapper();
        try {
            config = mapper.readValue(new File(FILTER_CONFIG_PATH), FilterConfig.class);
        } catch (IOException e) {
            LOGGER.error("Load filter config error: {}", e.getMessage());
            e.printStackTrace();
            config = null;
        }
        return config;
    }

    private static void loadId() {
        List<String> idList = new ArrayList<>();
        MaxComputeClient.run("select * from transaction_data where ingestion_date=20230708 limit 10;", result -> {
            for (Record record : result) {
                idList.add(record.getString("eventidentifier"));
            }
        });
        LOGGER.info("Load data from MC success: {}", idList);
    }

    @Override
    public void processElement(String msg, Context context, Collector<String> collector) throws Exception {
        LOGGER.info("Fetched MSG: {}", msg);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode eventNode;
        try{
            eventNode = mapper.readTree(msg);
        }catch (Exception e) {
            LOGGER.error("Read json msg failed: {}, msg: {}", e.getMessage(), msg);
            return;
        }
        // Filter
        JsonNode eventHeader = eventNode.get("eventHeader");
        if (eventHeader == null || isInvalid(eventHeader, FILTER_CONFIG.getHeaderFilterModels())) {
            return;
        }
        JsonNode eventDetails = eventNode.get("eventDetails");
        if (eventDetails == null || isInvalid(eventDetails, FILTER_CONFIG.getDetailFilterModels())) {
            return;
        }
        // Convert
        TransactionEvent transactionEvent = mapper.treeToValue(eventNode, TransactionEvent.class);
        DownStreamMessage message = MessageConvert.convertFromEvent(transactionEvent);
        // Forward
        String forwardMsg = mapper.writeValueAsString(message);
        LOGGER.info("Forward MSG: {}", forwardMsg);
        collector.collect(forwardMsg);
    }

    private boolean isInvalid(JsonNode node, List<FilterModel> filterModels) {
        for (FilterModel filterModel : filterModels) {
            String filterStrategy = filterModel.getFilterStrategy();
            ValueMatcher matcher = MatcherFactory.getMatcher(filterStrategy);
            if (matcher == null) {
                return true;
            }
            String filterKey = filterModel.getFilterKey();
            JsonNode keyNode = node.get(filterKey);
            if (keyNode == null) {
                LOGGER.error("No value found with KEY: {} in node: {}", filterKey, node);
                return true;
            }
            String actValue = keyNode.asText();
            List<String> filterValues = filterModel.getFilterValues();
            if (!matcher.match(actValue, filterValues)) {
                return true;
            }
        }
        return false;
    }
}
