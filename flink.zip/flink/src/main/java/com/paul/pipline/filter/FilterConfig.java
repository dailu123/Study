package com.paul.pipline.filter;

import java.util.List;

public class FilterConfig {
    private List<FilterModel> headerFilterModels;
    private List<FilterModel> detailFilterModels;

    public FilterConfig() {
    }

    public FilterConfig(List<FilterModel> headerFilterModels, List<FilterModel> detailFilterModels) {
        this.headerFilterModels = headerFilterModels;
        this.detailFilterModels = detailFilterModels;
    }

    public List<FilterModel> getHeaderFilterModels() {
        return headerFilterModels;
    }

    public void setHeaderFilterModels(List<FilterModel> headerFilterModels) {
        this.headerFilterModels = headerFilterModels;
    }

    public List<FilterModel> getDetailFilterModels() {
        return detailFilterModels;
    }

    public void setDetailFilterModels(List<FilterModel> detailFilterModels) {
        this.detailFilterModels = detailFilterModels;
    }
}
