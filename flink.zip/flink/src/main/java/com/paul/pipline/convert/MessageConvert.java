package com.paul.pipline.convert;

import com.paul.pojo.DownStreamMessage;
import com.paul.pojo.TransactionEvent;

public class MessageConvert {
    public static DownStreamMessage convertFromEvent(TransactionEvent event) {
        DownStreamMessage message = new DownStreamMessage();
        message.copyPropertyFromEvent(event);
        message.setProcessTime(Long.toString(System.currentTimeMillis()));
        return message;
    }
}
