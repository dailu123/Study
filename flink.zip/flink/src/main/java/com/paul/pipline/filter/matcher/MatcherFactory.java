package com.paul.pipline.filter.matcher;

import com.paul.cst.Constants;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

public class MatcherFactory {
    private static final Map<String, ValueMatcher> VALUE_MATCHER_MAP = new HashMap<>();

    static {
        VALUE_MATCHER_MAP.put(Constants.FILTER_STRATEGY_INCLUDE, new IncludeMatcher());
        VALUE_MATCHER_MAP.put(Constants.FILTER_STRATEGY_EXCLUDE, new ExcludeMatcher());
        VALUE_MATCHER_MAP.put(Constants.FILTER_STRATEGY_LIKE, new LikeMatcher());
        VALUE_MATCHER_MAP.put(Constants.FILTER_STRATEGY_NOT_LIKE, new NotLikeMatcher());
    }

    public static ValueMatcher getMatcher(String filterStrategy) {
        if (StringUtils.isEmpty(filterStrategy)) {
            return null;
        }
        final String key = filterStrategy.toUpperCase();
        return VALUE_MATCHER_MAP.get(key);
    }
}
