package com.paul.pipline.filter.matcher;

import java.util.List;

public class NotLikeMatcher implements ValueMatcher{
    @Override
    public boolean match(String actValue, List<String> cfgValueList) {
        for (String cfgValue : cfgValueList) {
            if (actValue.contains(cfgValue)) {
                return false;
            }
        }
        return true;
    }
}
