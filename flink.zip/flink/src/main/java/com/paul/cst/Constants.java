package com.paul.cst;

public class Constants {
    public static final String FILTER_STRATEGY_INCLUDE = "INCLUDE";
    public static final String FILTER_STRATEGY_EXCLUDE = "EXCLUDE";
    public static final String FILTER_STRATEGY_LIKE = "LIKE";
    public static final String FILTER_STRATEGY_NOT_LIKE = "NOT_LIKE";
}
