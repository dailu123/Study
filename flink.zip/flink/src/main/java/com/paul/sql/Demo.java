package com.paul.sql;

import com.paul.pojo.BankData;

import java.util.Arrays;
import java.util.List;

public class Demo {
    public static void main(String[] args) {
        String sql = "insert into bank_data_pt credit='no' (job, eduction) values ";
        BankData data = new BankData("teacher", "Collage");
        BankData data2 = new BankData("worker", "hight");
        List<BankData> bankData = Arrays.asList(data, data2);
        String finalSql = sql + bankData.toString().replace("[", "(").replace("]", ")");
        System.out.println(finalSql);
        //SqlRunner.tunnelQuery(sql, reader -> {

       // });
    }
}
