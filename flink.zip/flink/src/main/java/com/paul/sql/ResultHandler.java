package com.paul.sql;

public interface ResultHandler<T> {
    void handle(T result);
}
