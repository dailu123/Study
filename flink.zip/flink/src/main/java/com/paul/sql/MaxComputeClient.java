package com.paul.sql;

import com.aliyun.odps.Instance;
import com.aliyun.odps.Odps;
import com.aliyun.odps.OdpsException;
import com.aliyun.odps.account.Account;
import com.aliyun.odps.account.AliyunAccount;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.data.RecordReader;
import com.aliyun.odps.task.SQLTask;
import com.aliyun.odps.tunnel.TableTunnel;
import com.aliyun.odps.tunnel.io.TunnelRecordReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

public class MaxComputeClient {
    private static final Logger LOGGER = LoggerFactory.getLogger(MaxComputeClient.class);
    private static final String ACCESS_ID = "LTAI5tPxzpf4YtQ14vGyFXUo";
    private static final String ACCESS_KEY = "EDI2qjiNlVMz6ytkYAMULyRzcWdFnX";
    private static final String END_POINT_PUBLIC = "http://service.cn-shanghai.maxcompute.aliyun.com/api";
    private static final String END_POINT_PRIVATE = "http://service.cn-shanghai.maxcompute.aliyun-inc.com/api";
    private static final String PROJECT_NAME = "cb_poc_test_project";

    /**
     * query if record count is over 10000
     *
     * @param querySql query sql to run
     * @param handler result handler
     */
    public static void tunnelQuery(String querySql, ResultHandler<RecordReader> handler) {
        String tempTable = "Tmp_" + UUID.randomUUID().toString().replace("-", "");
        String createTempTableSql = "Create table " + tempTable + " lifecycle 1 as " + querySql;
        run(createTempTableSql, recordList -> {
            LOGGER.info("Create temp table [{}] success", tempTable);
            tunnel(tempTable, handler);
        });
    }

    private static void tunnel(String tableName, ResultHandler<RecordReader> handler) {
        LOGGER.info("Begin tunnel from: {}", tableName);
        long startTime = System.currentTimeMillis();
        Odps odps = createOdps();
        TableTunnel tunnel = new TableTunnel(odps);
        TunnelRecordReader recordReader = null;
        try {
            TableTunnel.DownloadSession downloadSession = tunnel.buildDownloadSession(PROJECT_NAME, tableName).setAsyncMode(false).build();
            long recordCount = downloadSession.getRecordCount();
            LOGGER.info("Record Count in table: [{}] is {}", tableName, recordCount);
            recordReader = downloadSession.openRecordReader(0, recordCount);
            if (handler != null) {
                handler.handle(recordReader);
            }
            LOGGER.info("Tunnel from {} finished, cost: {} ms", tableName, System.currentTimeMillis() - startTime);
        } catch (Exception e) {
            LOGGER.error("Run tunnel error: {}", e.getMessage());
        } finally {
            if (recordReader != null) {
                try {
                    recordReader.close();
                } catch (IOException e) {
                    LOGGER.error("Close TunnelRecordReader error: {}", e.getMessage());
                }
            }
        }
    }

    /**
     * Run provided SQL
     *
     * @param sql sql to run
     * @param handler result handler
     */
    public static void run(String sql, ResultHandler<List<Record>> handler) {
        LOGGER.info("Begin: [{}]", sql);
        long beginMs = System.currentTimeMillis();
        Odps odps = createOdps();
        List<Record> result;
        try {
            Instance instance = SQLTask.run(odps, sql);
            instance.waitForSuccess();
            result = SQLTask.getResult(instance);
        } catch (OdpsException e) {
            LOGGER.error("Run SQL [{}] error: {}", sql, e.getMessage());
            return;
        }
        LOGGER.info("End: [{}], cost: {} ms", sql, System.currentTimeMillis() - beginMs);
        if (handler != null) {
            handler.handle(result);
        }
    }

    private static Odps createOdps() {
        Account account = new AliyunAccount(ACCESS_ID, ACCESS_KEY);
        Odps odps = new Odps(account);
        odps.setEndpoint(END_POINT_PUBLIC);
        odps.setDefaultProject(PROJECT_NAME);
        return odps;
    }
}
